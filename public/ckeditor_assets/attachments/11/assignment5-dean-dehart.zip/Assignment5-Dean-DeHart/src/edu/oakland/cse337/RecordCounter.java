package edu.oakland.cse337;

import java.io.*;

/**
 * Created by Dean on 11/4/2016.
 */
public class RecordCounter {

    public RecordCounter() {


    }
    /**
     * The file must be comma separated in the form "field1,field2, other fields".
     * @param filename name of the file to be read.
     */
    public int[] readAndCount(String filename) {
        String currentLine;
        String[] fields;
        int field1, field2;
        int[] output = new int[2];
        output[0] = 0;
        output[1] = 0;
        try {
            InputStream inputStream = new FileInputStream(filename);
            InputStreamReader reader = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(reader);

            while ((currentLine = br.readLine()) != null) {
                fields = currentLine.trim().split(",");
                field1 = Integer.parseInt(fields[0]);
                field2 = Integer.parseInt(fields[1]);
                if (field1== 0) {
                    output[1] += field1;
                    output[0]++;
                } else {
                    if (field2 == 0) {
                        System.out.println("Total: " + output[1] + ", Counter: " + output[0]);
                        output[0] = 0;
                    } else {
                        output[1] -= field2;
                    }
                }
                System.out.println("End Record");
            }
        } catch (Exception e) {
            System.out.println("You've encountered an exception while reading the file!");
        }
        System.out.println("Counter: " + output[0]);
        return output;
    }
}