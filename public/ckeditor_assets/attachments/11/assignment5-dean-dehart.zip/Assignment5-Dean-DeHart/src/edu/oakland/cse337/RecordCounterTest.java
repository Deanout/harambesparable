package edu.oakland.cse337;

import org.junit.*;

/**
 * Oakland University
 * @author Dean DeHart
 * 161104
 */
public class RecordCounterTest {
    private RecordCounter recordCounter;

    @Before
    public void init() throws Exception {
        System.out.println("Getting things setup...");
        recordCounter = new RecordCounter();
        System.out.println("Setup Complete!");
    }

    @After
    public void destroy() throws Exception {
        System.out.println("Destroying...");
        recordCounter = null;
    }

    @Test
    public void testReadAndCountCounter() throws Exception {
        // The counter:
        Assert.assertEquals(5,recordCounter.readAndCount("test01.txt")[0]);
        Assert.assertEquals(0,recordCounter.readAndCount("test02.txt")[0]);
        Assert.assertEquals(0,recordCounter.readAndCount("test03.txt")[0]);
    }

    @Test
    public void testReadAndCountTotal() throws Exception {
        // The Total
        Assert.assertEquals(0, recordCounter.readAndCount("test01.txt")[1]);
        Assert.assertEquals(0, recordCounter.readAndCount("test02.txt")[1]);
        Assert.assertEquals(-5, recordCounter.readAndCount("test03.txt")[1]);
    }

    @Test
    public void testForException() {
        try {
            int attempt = recordCounter.readAndCount("test04.txt")[0];
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "You've encountered an exception while reading the file!");
        }
    }
}